function Student(studentId, studentName) {
    this.studentId = studentId;
    this.studentName = studentName;
}

export const students = [
    new Student(7963, 'Rutt Jeltsje'),
    new Student(7524, 'Janneke Nomusa'),
    new Student(3215, 'Willemijn Oluchi'),
    new Student(9600, 'Merike Kodjo'),
    new Student(5492, 'Bongani Afi'),
    new Student(5170, 'Anika Irene'),
    new Student(6749, 'Lelisa Melissa'),
    new Student(9532, 'Ebele Liselot'),
]