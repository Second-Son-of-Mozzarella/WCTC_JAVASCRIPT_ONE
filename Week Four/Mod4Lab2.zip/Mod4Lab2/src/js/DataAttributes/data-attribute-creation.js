
let myElement = document.querySelector('.addAnAttribute');

console.log(myElement.dataset.myAttribute);


let myElementTwo = document.querySelector(".addWithJavaScript");

console.log(myElementTwo.dataset.myAttributeWierd = '5');